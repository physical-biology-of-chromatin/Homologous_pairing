#####################################################################
# This script compiles and runs ButtonModel (by Daniel Jost - daniel.jost@ens-lyon.fr)
# to run the program:
# 1) modify the simulation parameters
# 2) define the position of homologous buttons in '/input/statep.out'
# 3) run the simulation by typing 'bash install-and-run.sh' in the terminal
#####################################################################

###################################################################
#       SIMULATION PARAMETERS
###################################################################

nchain=3200 #size of one chromosome
lx=12 #size of the simulation box in x-direction (number of FCC cells along the x-direction)
ly=12 #size of the simulation box in y-direction (number of FCC cells along the y-direction)
lz=23 #size of the simulation box in z-direction (number of FCC cells along the z-direction)
niter=1 #number of iterations
nmeas=2 #number of snapshots per iteration
ninter=100 #number of Monte-Carlo steps between consecutive snapshots
kint=1.5 #bending rigidity (in kT)
ei=-0.1 #interaction strength between (peri)centromeric beads (in kT)
ep=-2.0 #interaction strength between homologous button (in kT)
scentro=1000 #size of the (peri)centromeric regions

###################################################################
#       COMPILATION
###################################################################

t=$((4*${lx}*${ly}*2*${lz}))
td=$((10*${nmeas}*${niter}))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' ./src/input.dat
sed -i.back -e '2c\'$'\n '$lx' ::Lx' ./src/input.dat
sed -i.back -e '3c\'$'\n '$ly' ::Ly' ./src/input.dat
sed -i.back -e '4c\'$'\n '$lz' ::Lz' ./src/input.dat
sed -i.back -e '5c\'$'\n '$niter' ::Niter' ./src/input.dat
sed -i.back -e '6c\'$'\n '$nmeas' ::Nmeas' ./src/input.dat
sed -i.back -e '7c\'$'\n '$ninter' ::Ninter' ./src/input.dat
sed -i.back -e '8c\'$'\n '$kint' ::kint' ./src/input.dat
sed -i.back -e '9c\'$'\n '$ei' ::Ei' ./src/input.dat
sed -i.back -e '10c\'$'\n '$ep' ::Ep' ./src/input.dat
sed -i.back -e '11c\'$'\n '$scentro' ::scentro' ./src/input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config,config2,config3,config4' ./src/global.var
sed -i.back -e '4c\'$'\n integer,dimension(15,'$t') ::bittable' ./src/global.var
sed -i.back -e '8c\'$'\n integer,dimension('$nchain') ::state,state2,state3,state4,statep' ./src/global.var
sed -i.back -e '9c\'$'\n real,dimension(3,'$nchain') ::dr,dr2,dr3,dr4' ./src/global.var


cd src
make clean
make
cd ..

###################################################################
#       RUN
###################################################################
time ./src/buttonmodel
