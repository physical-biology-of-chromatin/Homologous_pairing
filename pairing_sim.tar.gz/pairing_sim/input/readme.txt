'statep.out' is a file containing the button-state of each monomer. It has one line with the state of the Nchain monomers. statep(i)=1 if monomer i is a button (=0 otherwise). 
