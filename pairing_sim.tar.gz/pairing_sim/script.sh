nchain=3200 #number of bead in one chromosome
lx=12 #box size in x-direction (number of FCC cells)
ly=12 #box size in y-direection (number of FCC cells)
lz=23 #box size in z-direction (number of FCC cells)
niter=1 #number of iterations
nmeas=61 #number of snapshots
ninter=30000 #number of MCS between consecutive snapshots
kint=1.5 #bending rigidity
nstate=1 #number of epigenetic state
ei=-0.1 #interaction strength between bead of the state epigenetic state
ep=-2.0 #interaction strength between homologous button
csize=0.65 #density of buttons
scentro=1000 #size of the (peri)ceentromeric regions

t=$((4*${lx}*${ly}*2*${lz}))
td=$((10*${nmeas}*${niter}))
sb=$((13+${nstate}+1))

sed -i.back -e '1c\'$'\n '$nchain' ::Nchain' input.dat
sed -i.back -e '2c\'$'\n '$lx' ::Lx' input.dat
sed -i.back -e '3c\'$'\n '$ly' ::Ly' input.dat
sed -i.back -e '4c\'$'\n '$lz' ::Lz' input.dat
sed -i.back -e '5c\'$'\n '$niter' ::Niter' input.dat
sed -i.back -e '6c\'$'\n '$nmeas' ::Nmeas' input.dat
sed -i.back -e '7c\'$'\n '$ninter' ::Ninter' input.dat
sed -i.back -e '8c\'$'\n '$kint' ::kint' input.dat
sed -i.back -e '9c\'$'\n '$nstate' ::Nstate' input.dat
sed -i.back -e '10c\'$'\n '$ei' ::Ei' input.dat
sed -i.back -e '11c\'$'\n '$ep' ::Ep' input.dat
sed -i.back -e '12c\'$'\n '$csize' ::csize' input.dat
sed -i.back -e '13c\'$'\n '$scentro' ::scentro' input.dat
sed -i.back -e '3c\'$'\n integer,dimension(2,'$nchain') ::config,config2,config3,config4' global.var
sed -i.back -e '4c\'$'\n integer,dimension('$sb','$t') ::bittable' global.var
sed -i.back -e '8c\'$'\n integer,dimension('$nchain') ::state,state2,state3,state4,statep' global.var
sed -i.back -e '9c\'$'\n real,dimension(3,'$nchain') ::dr,dr2,dr3,dr4' global.var


make clean
make

echo 'Lancement du programme'
./lat
