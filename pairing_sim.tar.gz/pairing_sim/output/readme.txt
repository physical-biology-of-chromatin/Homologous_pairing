'dist12.out': relative distances between homologous monomers of chromosome 1 & 2 (given in lattice unit, 1 lattice unit=sqrt(2)x nearest-neibor distance), one configuration after the other
'dist34.out': relative distances between homologous monomers of chromosome 3 & 4 (given in lattice unit, 1 lattice unit=sqrt(2)x nearest-neibor distance), one configuration after the other

Chromosomes 1 & 2 are homologs. 
Chromosomes 3 & 4 are homologs. 